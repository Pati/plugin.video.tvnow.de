class Sendung():
    def __init__(self, sid, title, cats, station, tGroup):
        self.sid = sid
        self.title = title
        self.cats = cats
        self.station = station
        self.tGroup = tGroup